import '../Models/user.dart';

class AuthService {
  // Hardcoded users for demonstration (in a real app, this would be from a database)
  static final List<User> _users = [
    User(
      id: '1',
      name: 'Member User',
      email: 'member@example.com',
      password: 'password123',
      role: Role.Member,
    ),
    User(
      id: '2',
      name: 'Librarian User',
      email: 'librarian@example.com',
      password: 'password123',
      role: Role.Librarian,
    ),
    User(
      id: '3',
      name: 'Manager User',
      email: 'manager@example.com',
      password: 'password123',
      role: Role.Manager,
    ),
  ];

  // Login function that validates credentials and returns user if valid
  static User? login(String email, String password) {
    try {
      return _users.firstWhere(
        (user) => user.email == email && user.password == password,
      );
    } catch (e) {
      // User not found
      return null;
    }
  }

  // Register function to add new users
  static bool register(String name, String email, String password, Role role) {
    // Check if user already exists
    if (_users.any((user) => user.email == email)) {
      return false; // User already exists
    }

    // Create new user
    String newId = (_users.length + 1).toString();
    User newUser = User(
      id: newId,
      name: name,
      email: email,
      password: password,
      role: role,
    );

    _users.add(newUser);
    return true; // Registration successful
  }

  // Future expansion: Add database integration here
  // For now, using hardcoded users as requested
}
