import 'package:flutter/material.dart';

class ManagerHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manager Home'),
      ),
      body: Center(
        child: Text('Manager Home Screen'),
      ),
    );
  }
}
