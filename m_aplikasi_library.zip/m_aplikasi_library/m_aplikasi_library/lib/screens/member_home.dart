import 'package:flutter/material.dart';

class MemberHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Member Home'),
      ),
      body: Center(
        child: Text('Member Home Screen'),
      ),
    );
  }
}
