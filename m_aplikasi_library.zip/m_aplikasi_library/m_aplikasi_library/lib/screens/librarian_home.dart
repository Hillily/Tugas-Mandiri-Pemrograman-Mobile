import 'package:flutter/material.dart';

class LibrarianHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Librarian Home'),
      ),
      body: Center(
        child: Text('Librarian Home Screen'),
      ),
    );
  }
}
