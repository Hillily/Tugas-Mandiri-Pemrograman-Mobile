import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/member_home.dart';
import 'screens/librarian_home.dart';
import 'screens/manager_home.dart';

void main() {
  runApp(MLibraryApp());
}

class MLibraryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'M-Library',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.red,
        ).copyWith(
          secondary: Colors.blue,
          tertiary: Color(0xFFD4AF37),
        ),
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/memberHome': (context) => MemberHome(),
        '/librarianHome': (context) => LibrarianHome(),
        '/managerHome': (context) => ManagerHome(),
      },
    );
  }
}
