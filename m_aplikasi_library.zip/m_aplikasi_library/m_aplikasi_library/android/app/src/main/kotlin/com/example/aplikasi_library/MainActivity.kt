package com.example.aplikasi_library

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
